radius = 2.7
area = 3.14*radius ** 2
print(area)
