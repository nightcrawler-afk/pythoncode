try:
    l1 = []

    while True:
        l1.append(int(input("Enter list element")))
    
except:
    print(l1)
