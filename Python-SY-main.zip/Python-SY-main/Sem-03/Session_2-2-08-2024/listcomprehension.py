# Code to print square of n numbers, n is an input from user.
print([x**2 for x in range(1, int(input("Enter a number")))])
